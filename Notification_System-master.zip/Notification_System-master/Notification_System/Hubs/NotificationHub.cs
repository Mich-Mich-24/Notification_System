﻿using Microsoft.AspNetCore.SignalR;

namespace Notification_System.Hubs
{
    public class NotificationHub : Hub
    {
        public async Task RegisterForPush(string pushId)
        {
            await Groups.AddToGroupAsync(Context.ConnectionId, pushId);
        }
    }
}