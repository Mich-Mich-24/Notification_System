using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Notification_System.Models;

namespace Notification_System.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IServiceProvider _serviceProvider;
        private readonly NotificationManager _notificationManager;

        public HomeController(ApplicationDbContext context, IServiceProvider serviceProvider)
        {
            _context = context;
            _serviceProvider = serviceProvider;
            _notificationManager = NotificationManager.GetInstance(serviceProvider);
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Index(string name, string selectedType, string email, string phoneNumber, string pushId)
        {
            try
            {
                // Validate required fields
                if (string.IsNullOrEmpty(name)) throw new ArgumentException("Name is required");
                if (string.IsNullOrEmpty(selectedType)) throw new ArgumentException("Notification type is required");

                // Create user
                var user = new User
                {
                    Name = name,
                    Email = selectedType == "Email" ? email : null,
                    PhoneNumber = selectedType == "SMS" ? phoneNumber : null,
                    PushId = selectedType == "Push" ? pushId : null
                };

                // Save to database
                _context.Users.Add(user);
                await _context.SaveChangesAsync(); // This is where the error likely occurs
                
                // Add to notification manager
                var notification = NotificationFactory.CreateNotification(selectedType, _serviceProvider);
                user.SetNotificationMethod(notification);
                user.ContactInfo = selectedType switch
                {
                    "Email" => email,
                    "SMS" => phoneNumber,
                    "Push" => pushId,
                    _ => throw new ArgumentException("Invalid notification type")
                };
                _notificationManager.Subscribers.Add(user);

                // Send welcome notification
                var welcomeMessage = $"Welcome {name}! You've successfully subscribed to {selectedType} notifications.";
                notification.Send(user.ContactInfo, welcomeMessage);

                ViewBag.Message = $"{name} subscribed to {selectedType} notifications. A confirmation has been sent.";
            }
            catch (Exception ex)
            {
                // Get the innermost exception
                while (ex.InnerException != null)
                {
                    ex = ex.InnerException;
                }
                ViewBag.Error = $"Error: {ex.Message}";
            }

            return View();
        }

        [HttpGet]
        public IActionResult Notify()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Notify(string message)
        {
            _notificationManager.NotifyAll(message);
            ViewBag.Status = $"Notification sent to {_notificationManager.Subscribers.Count} subscribers.";
            return View();
        }
    }
}