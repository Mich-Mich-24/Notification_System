﻿using Microsoft.Extensions.Options;
using SendGrid;
using SendGrid.Helpers.Mail;
using System.Threading.Tasks;

namespace Notification_System.Models
{
    public class EmailNotification : INotification
    {
        private readonly SendGridSettings _settings;

        public EmailNotification(IOptions<SendGridSettings> settings)
        {
            _settings = settings.Value;
        }

        public void Send(string recipient, string message)
        {
            var client = new SendGridClient(_settings.ApiKey);
            var from = new EmailAddress(_settings.FromEmail, _settings.FromName);
            var to = new EmailAddress(recipient);
            var msg = MailHelper.CreateSingleEmail(from, to, "Notification", message, message);

            // Async void is generally bad practice, but we'll use Wait() here
            client.SendEmailAsync(msg).Wait();
        }
    }
}