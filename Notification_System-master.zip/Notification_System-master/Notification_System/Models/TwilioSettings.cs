﻿namespace Notification_System.Models
{
    public class TwilioSettings
    {
        public string? AccountSid { get; set; }
        public string? AuthToken { get; set; }
        public string? PhoneNumber { get; set; }
    }
}