﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Notification_System.Models
{
    [Table("Users")]
    public class User : IObserver
    {
        [Key]
        [Column("UserId")] // Explicitly maps to your database column
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int UserId { get; set; } // Changed from Id to UserId

        // Keep all other properties the same
        public string? Name { get; set; }
        public string? Email { get; set; }
        public string? PhoneNumber { get; set; }
        public string? PushId { get; set; }

        [NotMapped]
        public INotification? Notification { get; set; }

        [NotMapped]
        public string? ContactInfo { get; set; }

        public void Update(string message)
        {
            if (Notification != null && ContactInfo != null)
            {
                Notification.Send(ContactInfo, message);
            }
        }

        public void SetNotificationMethod(INotification notification)
        {
            Notification = notification;
        }
    }
}