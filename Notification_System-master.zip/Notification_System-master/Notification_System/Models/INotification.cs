﻿namespace Notification_System.Models
{
    public interface INotification
    {
        void Send(string recipient, string message);
    }
}