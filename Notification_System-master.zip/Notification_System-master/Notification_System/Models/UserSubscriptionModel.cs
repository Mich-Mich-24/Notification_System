﻿using System.ComponentModel.DataAnnotations;

namespace Notification_System.Models
{
    public class UserSubscriptionModel
    {
        [Required(ErrorMessage = "Name is required")]
        public string Name { get; set; } = null!; // Add = null!

        [Required(ErrorMessage = "Notification type is required")]
        public string SelectedType { get; set; } = null!;

        [EmailAddress(ErrorMessage = "Invalid email address")]
        public string? Email { get; set; } // Make nullable

        [RegularExpression(@"^\+?[0-9]{10,}$", ErrorMessage = "Invalid phone number")]
        public string? PhoneNumber { get; set; }

        public string? PushId { get; set; }
    }
}