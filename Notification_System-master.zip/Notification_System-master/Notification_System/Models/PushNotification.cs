﻿using Microsoft.AspNetCore.SignalR;
using Notification_System.Hubs;

namespace Notification_System.Models
{
    public class PushNotification : INotification
    {
        private readonly IHubContext<NotificationHub> _hubContext;

        public PushNotification(IHubContext<NotificationHub> hubContext)
        {
            _hubContext = hubContext;
        }

        public void Send(string recipient, string message)
        {
            _hubContext.Clients.Group(recipient).SendAsync("ReceiveNotification", message).Wait();
        }
    }
}