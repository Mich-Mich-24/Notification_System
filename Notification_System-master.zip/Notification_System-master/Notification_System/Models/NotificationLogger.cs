﻿using Microsoft.EntityFrameworkCore;
using System;

namespace Notification_System.Models
{
    public static class NotificationLogger
    {
        public static void Log(string recipient, string type, string message)
        {
            using var context = new ApplicationDbContext(
                new DbContextOptionsBuilder<ApplicationDbContext>()
                    .UseSqlServer("Server=.;Database=NotificationSystem;Trusted_Connection=True;TrustServerCertificate=True;")
                    .Options);

            context.Database.ExecuteSqlRaw(
                "INSERT INTO SentNotifications (NotificationType, Recipient, Message) VALUES ({0}, {1}, {2})",
                type, recipient, message);
        }
    }
}