﻿using Microsoft.Extensions.DependencyInjection;

namespace Notification_System.Models
{
    public static class NotificationFactory
    {
        public static INotification CreateNotification(string type, IServiceProvider serviceProvider)
        {
            return type.ToLower() switch
            {
                "email" => serviceProvider.GetRequiredService<EmailNotification>(),
                "sms" => serviceProvider.GetRequiredService<SMSNotification>(),
                "push" => serviceProvider.GetRequiredService<PushNotification>(),
                _ => throw new System.NotImplementedException($"Notification type {type} not implemented")
            };
        }
    }
}