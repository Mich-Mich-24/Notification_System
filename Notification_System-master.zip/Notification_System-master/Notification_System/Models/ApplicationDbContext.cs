﻿using Microsoft.EntityFrameworkCore;
using Notification_System.Models;

namespace Notification_System
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<SentNotification> SentNotifications { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(u => u.UserId); entity.Property(u => u.Name).IsRequired(false);
                entity.Property(u => u.Email).IsRequired(false);
                entity.Property(u => u.PhoneNumber).IsRequired(false);
                entity.Property(u => u.PushId).IsRequired(false);
            });
        }
    }
}