﻿public static class NotificationFactoryBase1
{
}