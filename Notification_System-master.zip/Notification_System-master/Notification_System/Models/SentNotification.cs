﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Notification_System.Models
{
    public class SentNotification
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        public int? UserId { get; set; }

        [Required]
        [StringLength(20)]
        public string NotificationType { get; set; } = null!;

        [Required]
        [StringLength(200)]
        public string Recipient { get; set; } = null!;

        [Required]
        [StringLength(500)]
        public string Message { get; set; } = null!;

        public DateTime SentDate { get; set; } = DateTime.UtcNow;

        [StringLength(20)]
        public string Status { get; set; } = "Sent";

        [ForeignKey("UserId")]
        public virtual User? User { get; set; }
    }
}