﻿public static class NotificationFactoryBase
{
}