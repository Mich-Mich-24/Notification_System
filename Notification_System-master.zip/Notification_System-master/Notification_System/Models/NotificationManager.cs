﻿using Microsoft.Extensions.DependencyInjection;

namespace Notification_System.Models
{
    public class NotificationManager
    {
        private static NotificationManager? _instance; // Add ? to make it nullable
        private static readonly object _lock = new();
        public List<User> Subscribers { get; } = new();
        private readonly IServiceProvider _serviceProvider;

        private NotificationManager(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider ?? throw new ArgumentNullException(nameof(serviceProvider));
        }

        public static NotificationManager GetInstance(IServiceProvider serviceProvider)
        {
            lock (_lock)
            {
                return _instance ??= new NotificationManager(serviceProvider);
            }
        }

        public void NotifyAll(string message)
        {
            foreach (var user in Subscribers)
            {
                if (user.Notification == null)
                {
                    // Create appropriate notification based on user's contact info
                    if (!string.IsNullOrEmpty(user.Email))
                    {
                        user.SetNotificationMethod(NotificationFactory.CreateNotification("email", _serviceProvider));
                        user.ContactInfo = user.Email;
                    }
                    else if (!string.IsNullOrEmpty(user.PhoneNumber))
                    {
                        user.SetNotificationMethod(NotificationFactory.CreateNotification("sms", _serviceProvider));
                        user.ContactInfo = user.PhoneNumber;
                    }
                    else if (!string.IsNullOrEmpty(user.PushId))
                    {
                        user.SetNotificationMethod(NotificationFactory.CreateNotification("push", _serviceProvider));
                        user.ContactInfo = user.PushId;
                    }
                }

                if (user.Notification != null)
                {
                    user.Update(message);
                }
            }
        }
    }
}