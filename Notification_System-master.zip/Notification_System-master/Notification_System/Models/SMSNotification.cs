﻿using Microsoft.Extensions.Options;
using Twilio;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;

namespace Notification_System.Models
{
    public class SMSNotification : INotification
    {
        private readonly TwilioSettings _settings;

        public SMSNotification(IOptions<TwilioSettings> settings)
        {
            _settings = settings.Value;
            TwilioClient.Init(_settings.AccountSid, _settings.AuthToken);
        }

        public void Send(string recipient, string message)
        {
            // Format the phone number
            var formattedNumber = FormatPhoneNumber(recipient);

            MessageResource.Create(
                body: message,
                from: new PhoneNumber(_settings.PhoneNumber),
                to: new PhoneNumber(formattedNumber)
            );
        }

        private string FormatPhoneNumber(string number)
        {
            // Remove all non-digit characters
            var digits = new string(number.Where(char.IsDigit).ToArray());

            // Handle South African numbers (add country code if missing)
            if (digits.StartsWith("0") && digits.Length == 10)
            {
                return "+27" + digits.Substring(1);
            }

            // If already in international format
            if (digits.StartsWith("27") && digits.Length == 11)
            {
                return "+" + digits;
            }

            // Add your country's specific formatting if needed
            return "+" + digits; // Default fallback
        }
    }
}